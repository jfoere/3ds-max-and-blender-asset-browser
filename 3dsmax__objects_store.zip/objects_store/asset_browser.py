"""
3ds Max Local Asset Browser
============================
A Chaos-Browser-style local asset panel for 3ds Max 2022+.
Opens a floating PySide2 dialog listing assets from catalog.json.
Users can browse, search, filter by category, and import assets
directly into the active 3ds Max scene.

Compatible: 3ds Max 2022, 2023, 2024, 2025+
API:        pymxs + PySide2 + qtmax
Author:     Your Studio
"""

from __future__ import annotations

import json
import os
import sys

# ── Guard: must run inside 3ds Max ────────────────────────────────────────────
try:
    import pymxs
    import qtmax
    from pymxs import runtime as rt
    INSIDE_MAX = True
except ImportError:
    INSIDE_MAX = False   # allows opening the file in a regular editor

from PySide2 import QtCore, QtGui, QtWidgets
from PySide2.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve, QSettings

# ── Constants ─────────────────────────────────────────────────────────────────
PLUGIN_DIR   = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(PLUGIN_DIR, "catalog.json")
THUMBS_DIR   = os.path.join(PLUGIN_DIR, "thumbs")
ASSETS_DIR   = os.path.join(PLUGIN_DIR, "assets")

CARD_W, CARD_H   = 170, 190
THUMB_W, THUMB_H = 150, 120
GRID_COLS        = 3

# Category → (light accent, dark accent)
CATEGORY_PALETTE: dict[str, tuple[str, str]] = {
    "Props":        ("#4CAF50", "#1B5E20"),
    "Architecture": ("#2196F3", "#0D47A1"),
    "Nature":       ("#FFC107", "#E65100"),
    "Vehicles":     ("#F44336", "#B71C1C"),
    "Furniture":    ("#9C27B0", "#4A148C"),
    "Other":        ("#607D8B", "#263238"),
}

# ── StyleSheet ────────────────────────────────────────────────────────────────
GLOBAL_QSS = """
QWidget {
    background: #1e1e2e;
    color: #e0e0f0;
    font-family: "Segoe UI", Arial, sans-serif;
    font-size: 12px;
}

QLineEdit {
    background: #2a2a3d;
    border: 1px solid #44446a;
    border-radius: 6px;
    padding: 5px 10px;
    color: #e0e0f0;
    font-size: 13px;
}
QLineEdit:focus {
    border: 1px solid #7c7cf0;
}

QComboBox {
    background: #2a2a3d;
    border: 1px solid #44446a;
    border-radius: 6px;
    padding: 5px 10px;
    color: #e0e0f0;
    min-width: 120px;
}
QComboBox::drop-down {
    border: none;
}
QComboBox QAbstractItemView {
    background: #2a2a3d;
    border: 1px solid #44446a;
    selection-background-color: #3d3d5c;
    color: #e0e0f0;
}

QPushButton#addBtn {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #7c7cf0, stop:1 #5555cc);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 22px;
    font-size: 13px;
    font-weight: bold;
    letter-spacing: 0.5px;
}
QPushButton#addBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #9090ff, stop:1 #6666dd);
}
QPushButton#addBtn:pressed {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #5555cc, stop:1 #4444aa);
}
QPushButton#addBtn:disabled {
    background: #3a3a5a;
    color: #666;
}

QScrollArea {
    border: none;
    background: transparent;
}
QScrollBar:vertical {
    background: #2a2a3d;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #55557a;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

QLabel#statusLabel {
    color: #9090b0;
    font-size: 11px;
    padding: 2px 8px;
}

QFrame#topBar {
    background: #252538;
    border-bottom: 1px solid #33334a;
}
QFrame#bottomBar {
    background: #252538;
    border-top: 1px solid #33334a;
}
"""

CARD_SELECTED_BORDER = 3  # px


# ── Asset Card Widget ─────────────────────────────────────────────────────────

class AssetCard(QtWidgets.QFrame):
    """A single clickable asset card with thumbnail, category strip, and name."""

    clicked = QtCore.Signal(object)   # emits the asset dict

    def __init__(self, asset: dict, parent=None):
        super().__init__(parent)
        self.asset = asset
        self._selected = False
        self._hover = False

        cat = asset.get("category", "Other")
        light, dark = CATEGORY_PALETTE.get(cat, CATEGORY_PALETTE["Other"])
        self._cat_color_light = light
        self._cat_color_dark  = dark

        self.setFixedSize(CARD_W, CARD_H)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(asset.get("description", asset["name"]))
        self._build_ui()

    def _build_ui(self):
        self.setObjectName("assetCard")
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Colored category header strip ────────────────────────────
        self.header = QtWidgets.QLabel()
        self.header.setFixedHeight(8)
        self.header.setStyleSheet(
            f"background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 {self._cat_color_light}, stop:1 {self._cat_color_dark});"
            f"border-radius: 8px 8px 0 0;"
        )
        layout.addWidget(self.header)

        # ── Thumbnail area ────────────────────────────────────────────
        self.thumb_label = QtWidgets.QLabel()
        self.thumb_label.setFixedSize(CARD_W, THUMB_H)
        self.thumb_label.setAlignment(Qt.AlignCenter)
        self.thumb_label.setStyleSheet("background: #2a2a3d;")

        thumb_path = os.path.join(PLUGIN_DIR, self.asset.get("thumbnail", ""))
        if os.path.isfile(thumb_path):
            pix = QtGui.QPixmap(thumb_path).scaled(
                THUMB_W, THUMB_H, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.thumb_label.setPixmap(pix)
        else:
            # Fallback: coloured placeholder with icon letter
            self.thumb_label.setText(self.asset["name"][0].upper())
            self.thumb_label.setStyleSheet(
                f"background: qlineargradient(x1:0,y1:0,x2:0,y2:1,"
                f"stop:0 {self._cat_color_light}44, stop:1 {self._cat_color_dark}44);"
                f"font-size: 42px; font-weight: bold; color: {self._cat_color_light};"
            )
        layout.addWidget(self.thumb_label)

        # ── Name + category label ─────────────────────────────────────
        bottom = QtWidgets.QWidget()
        bottom.setStyleSheet("background: #232335;")
        bl = QtWidgets.QVBoxLayout(bottom)
        bl.setContentsMargins(8, 4, 8, 6)
        bl.setSpacing(1)

        name_lbl = QtWidgets.QLabel(self.asset["name"])
        name_lbl.setStyleSheet("color: #e0e0f0; font-weight: bold; font-size: 12px; background: transparent;")
        name_lbl.setWordWrap(False)

        cat_lbl = QtWidgets.QLabel(self.asset.get("category", ""))
        cat_lbl.setStyleSheet(
            f"color: {self._cat_color_light}; font-size: 10px; background: transparent;"
        )

        bl.addWidget(name_lbl)
        bl.addWidget(cat_lbl)
        layout.addWidget(bottom)

        self._refresh_style()

    def _refresh_style(self):
        if self._selected:
            border_css = f"border: {CARD_SELECTED_BORDER}px solid {self._cat_color_light};"
            shadow_color = self._cat_color_light
        elif self._hover:
            border_css = f"border: 1px solid {self._cat_color_light}88;"
            shadow_color = None
        else:
            border_css = "border: 1px solid #33334a;"
            shadow_color = None

        self.setStyleSheet(
            f"QFrame#assetCard {{ background: #2a2a3d; border-radius: 10px; {border_css} }}"
        )

        if shadow_color:
            eff = QtWidgets.QGraphicsDropShadowEffect(self)
            r, g, b = (int(shadow_color[i:i+2], 16) for i in (1, 3, 5))
            eff.setColor(QtGui.QColor(r, g, b, 160))
            eff.setBlurRadius(22)
            eff.setOffset(0, 0)
            self.setGraphicsEffect(eff)
        else:
            self.setGraphicsEffect(None)

    # ── Selection state ───────────────────────────────────────────────────────
    def set_selected(self, sel: bool):
        self._selected = sel
        self._refresh_style()

    # ── Mouse events ──────────────────────────────────────────────────────────
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self.asset)
        super().mousePressEvent(event)

    def enterEvent(self, event):
        self._hover = True
        self._refresh_style()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover = False
        self._refresh_style()
        super().leaveEvent(event)


# ── Flow Layout ───────────────────────────────────────────────────────────────

class FlowLayout(QtWidgets.QLayout):
    """Wraps child widgets into rows automatically."""

    def __init__(self, parent=None, h_spacing=12, v_spacing=12):
        super().__init__(parent)
        self._items: list = []
        self._h_spacing = h_spacing
        self._v_spacing = v_spacing

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, idx):
        if 0 <= idx < len(self._items):
            return self._items[idx]
        return None

    def takeAt(self, idx):
        if 0 <= idx < len(self._items):
            return self._items.pop(idx)
        return None

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._layout(QtCore.QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._layout(rect, test_only=False)

    def sizeHint(self):
        parent = self.parent()
        if parent is not None:
            w = max(parent.width(), CARD_W + 32)
            h = self.heightForWidth(w)
            return QtCore.QSize(w, h)
        return self.minimumSize()

    def minimumSize(self):
        size = QtCore.QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        m = self.contentsMargins()
        size += QtCore.QSize(m.left() + m.right(), m.top() + m.bottom())
        return size

    def _layout(self, rect: QtCore.QRect, test_only: bool) -> int:
        m = self.contentsMargins()
        effective = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y = effective.x(), effective.y()
        row_height = 0
        for item in self._items:
            w = item.widget()
            if w and not w.isVisible():
                continue
            item_w = item.sizeHint().width()
            item_h = item.sizeHint().height()
            next_x = x + item_w + self._h_spacing
            if next_x - self._h_spacing > effective.right() and row_height > 0:
                x = effective.x()
                y += row_height + self._v_spacing
                row_height = 0
                next_x = x + item_w + self._h_spacing
            if not test_only:
                item.setGeometry(QtCore.QRect(QtCore.QPoint(x, y), item.sizeHint()))
            x = next_x
            row_height = max(row_height, item_h)
        return y + row_height - rect.y() + m.bottom()


# ── Main Asset Browser Dialog ─────────────────────────────────────────────────

class AssetBrowserDialog(QtWidgets.QDialog):

    SETTINGS_ORG  = "YourStudio"
    SETTINGS_APP  = "MaxAssetBrowser"

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Window)
        self.setWindowTitle("🗂  Asset Browser")
        self.setWindowIcon(self._make_icon())
        self.setMinimumSize(580, 600)
        self.setStyleSheet(GLOBAL_QSS)

        self._all_assets: list[dict] = []
        self._selected_asset: dict | None = None
        self._cards: list[AssetCard] = []

        self._load_catalog()
        self._build_ui()
        self._populate_grid(self._all_assets)
        self._restore_geometry()

    # ── Catalog ───────────────────────────────────────────────────────────────
    def _load_catalog(self):
        if not os.path.isfile(CATALOG_PATH):
            QtWidgets.QMessageBox.warning(
                self, "Catalog missing",
                f"Could not find catalog.json at:\n{CATALOG_PATH}"
            )
            return
        with open(CATALOG_PATH, "r", encoding="utf-8") as f:
            self._all_assets = json.load(f)

    # ── UI Construction ───────────────────────────────────────────────────────
    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Top toolbar ───────────────────────────────────────────────
        top_bar = QtWidgets.QFrame()
        top_bar.setObjectName("topBar")
        top_bar.setFixedHeight(56)
        tb_layout = QtWidgets.QHBoxLayout(top_bar)
        tb_layout.setContentsMargins(12, 8, 12, 8)
        tb_layout.setSpacing(10)

        # Logo / title
        title_lbl = QtWidgets.QLabel("Asset Browser")
        title_lbl.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #c0c0ff; background: transparent;"
        )
        tb_layout.addWidget(title_lbl)
        tb_layout.addSpacerItem(
            QtWidgets.QSpacerItem(20, 20, QtWidgets.QSizePolicy.Expanding)
        )

        # Search
        self.search_box = QtWidgets.QLineEdit()
        self.search_box.setPlaceholderText("🔍  Search assets…")
        self.search_box.setFixedWidth(200)
        self.search_box.textChanged.connect(self._on_filter_changed)
        tb_layout.addWidget(self.search_box)

        # Category filter
        self.cat_combo = QtWidgets.QComboBox()
        categories = sorted(set(a.get("category", "Other") for a in self._all_assets))
        self.cat_combo.addItem("All Categories")
        self.cat_combo.addItems(categories)
        self.cat_combo.currentTextChanged.connect(self._on_filter_changed)
        tb_layout.addWidget(self.cat_combo)

        root.addWidget(top_bar)

        # ── Scrollable asset grid ─────────────────────────────────────
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.grid_container = QtWidgets.QWidget()
        self.grid_container.setStyleSheet("background: #1e1e2e;")
        self.flow_layout = FlowLayout(self.grid_container, h_spacing=14, v_spacing=14)
        self.flow_layout.setContentsMargins(16, 16, 16, 16)
        self.grid_container.setLayout(self.flow_layout)

        scroll.setWidget(self.grid_container)
        root.addWidget(scroll, stretch=1)

        # ── Bottom action bar ─────────────────────────────────────────
        bot_bar = QtWidgets.QFrame()
        bot_bar.setObjectName("bottomBar")
        bot_bar.setFixedHeight(54)
        bb_layout = QtWidgets.QHBoxLayout(bot_bar)
        bb_layout.setContentsMargins(14, 8, 14, 8)
        bb_layout.setSpacing(12)

        self.status_label = QtWidgets.QLabel("Select an asset to add it to your scene.")
        self.status_label.setObjectName("statusLabel")
        bb_layout.addWidget(self.status_label, stretch=1)

        self.count_label = QtWidgets.QLabel()
        self.count_label.setObjectName("statusLabel")
        bb_layout.addWidget(self.count_label)

        self.gen_btn = QtWidgets.QPushButton("🖼  Generate Previews")
        self.gen_btn.setObjectName("genBtn")
        self.gen_btn.setFixedHeight(36)
        self.gen_btn.setStyleSheet("""
            QPushButton#genBtn {
                background: #3d3d5c;
                color: #c0c0ff;
                border: 1px solid #55557a;
                border-radius: 8px;
                padding: 8px 16px;
            }
            QPushButton#genBtn:hover { background: #4d4d7a; }
        """)
        self.gen_btn.clicked.connect(self._on_generate_thumbs)
        bb_layout.addWidget(self.gen_btn)

        self.add_btn = QtWidgets.QPushButton("⊕  Add to Scene")
        self.add_btn.setObjectName("addBtn")
        self.add_btn.setFixedHeight(36)
        self.add_btn.setEnabled(False)
        self.add_btn.clicked.connect(self._on_add_to_scene)
        bb_layout.addWidget(self.add_btn)

        root.addWidget(bot_bar)

    # ── Grid population ───────────────────────────────────────────────────────
    def _populate_grid(self, assets: list[dict]):
        # Remove old cards
        for card in self._cards:
            self.flow_layout.removeWidget(card)
            card.deleteLater()
        self._cards.clear()
        self._selected_asset = None
        self.add_btn.setEnabled(False)
        self.status_label.setText("Select an asset to add it to your scene.")

        for asset in assets:
            card = AssetCard(asset, self.grid_container)
            card.clicked.connect(self._on_card_clicked)
            self.flow_layout.addWidget(card)
            self._cards.append(card)

        n = len(assets)
        self.count_label.setText(f"{n} asset{'s' if n != 1 else ''}")
        # Force the container to recalculate its size so all cards show
        self.flow_layout.invalidate()
        self.grid_container.updateGeometry()
        self.grid_container.adjustSize()
        QtCore.QTimer.singleShot(50, self.grid_container.adjustSize)

    # ── Filtering ─────────────────────────────────────────────────────────────
    def _on_filter_changed(self):
        query    = self.search_box.text().lower().strip()
        cat_text = self.cat_combo.currentText()

        filtered = []
        for a in self._all_assets:
            # Category filter
            if cat_text != "All Categories" and a.get("category") != cat_text:
                continue
            # Text search: name + tags
            if query:
                haystack = a["name"].lower() + " " + " ".join(a.get("tags", []))
                if query not in haystack:
                    continue
            filtered.append(a)

        self._populate_grid(filtered)

    # ── Card selection ────────────────────────────────────────────────────────
    def _on_card_clicked(self, asset: dict):
        # Deselect previous
        for card in self._cards:
            card.set_selected(card.asset is asset)

        self._selected_asset = asset
        self.add_btn.setEnabled(True)
        self.status_label.setText(
            f"Selected: {asset['name']}  ·  {asset.get('category', '')}"
        )

    # ── Import into Max ───────────────────────────────────────────────────────
    def _on_add_to_scene(self):
        if not self._selected_asset:
            return
        asset = self._selected_asset
        file_rel = asset.get("file", "")
        file_path = os.path.join(PLUGIN_DIR, file_rel.replace("/", os.sep))

        if not os.path.isfile(file_path):
            QtWidgets.QMessageBox.warning(
                self, "File not found",
                f"Could not locate asset file:\n{file_path}"
            )
            return

        if INSIDE_MAX:
            try:
                # Import file without showing Max's native import dialog
                rt.importFile(file_path, rt.name("noPrompt"))

                # Apply the category color to the newly imported objects (which are selected by default)
                cat = asset.get("category", "Other")
                c_light, _ = CATEGORY_PALETTE.get(cat, CATEGORY_PALETTE["Other"])
                
                # Convert hex to RGB (e.g. "#4CAF50" -> 76, 175, 80)
                r = int(c_light[1:3], 16)
                g = int(c_light[3:5], 16)
                b = int(c_light[5:7], 16)
                max_color = rt.color(r, g, b)

                # Update wirecolor of imported nodes AND remove any default gray material
                for node in rt.selection:
                    node.wirecolor = max_color
                    node.material = rt.undefined

                self.status_label.setText(
                    f"✔  '{asset['name']}' added to scene (colored {cat})."
                )
            except Exception as exc:
                QtWidgets.QMessageBox.critical(
                    self, "Import Error", str(exc)
                )
        else:
            # Running outside Max — show simulated message
            QtWidgets.QMessageBox.information(
                self, "Simulation Mode",
                f"[Outside 3ds Max]\n\nWould import:\n{file_path}"
            )

    # ── Thumbnail Generation ──────────────────────────────────────────────────
    def _on_generate_thumbs(self):
        self.gen_btn.setText("Generating...")
        self.gen_btn.setEnabled(False)
        QtWidgets.QApplication.processEvents()

        try:
            # Import our new Qt-based generator
            import generate_thumbs_qt
            
            # Since we're inside the same Python process, force a reload 
            # in case the user edited the generator script
            import importlib
            importlib.reload(generate_thumbs_qt)

            count = generate_thumbs_qt.generate_all_thumbnails()
            
            self.status_label.setText(f"✔  Generated {count} thumbnails.")
            
            # Reload catalog to pick up new images
            self._load_catalog()
            self._on_filter_changed()  # Refresh grid

        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Error Generating Thumbs", str(exc))
        finally:
            self.gen_btn.setText("🖼  Generate Previews")
            self.gen_btn.setEnabled(True)

    # ── Geometry persistence ──────────────────────────────────────────────────
    def _restore_geometry(self):
        settings = QSettings(self.SETTINGS_ORG, self.SETTINGS_APP)
        geom = settings.value("geometry")
        if geom:
            self.restoreGeometry(geom)

    def closeEvent(self, event):
        settings = QSettings(self.SETTINGS_ORG, self.SETTINGS_APP)
        settings.setValue("geometry", self.saveGeometry())
        super().closeEvent(event)

    # ── Icon ──────────────────────────────────────────────────────────────────
    @staticmethod
    def _make_icon() -> QtGui.QIcon:
        pix = QtGui.QPixmap(32, 32)
        pix.fill(Qt.transparent)
        painter = QtGui.QPainter(pix)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        grad = QtGui.QLinearGradient(0, 0, 32, 32)
        grad.setColorAt(0, QtGui.QColor("#7c7cf0"))
        grad.setColorAt(1, QtGui.QColor("#4CAF50"))
        painter.setBrush(QtGui.QBrush(grad))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(2, 2, 28, 28, 6, 6)
        painter.setPen(QtGui.QColor("white"))
        painter.setFont(QtGui.QFont("Segoe UI", 16, QtGui.QFont.Bold))
        painter.drawText(pix.rect(), Qt.AlignCenter, "A")
        painter.end()
        return QtGui.QIcon(pix)


# ── Entry Point ───────────────────────────────────────────────────────────────

_dialog_instance: AssetBrowserDialog | None = None


def _get_max_main_window():
    """Return the 3ds Max main Qt window, trying several API variants."""
    if not INSIDE_MAX:
        return None
    # Try each known variant across different Max versions
    for fn_name in ("GetMaxMainWindow", "GetQMaxMainWindow", "GetMaxWindow"):
        fn = getattr(qtmax, fn_name, None)
        if callable(fn):
            try:
                return fn()
            except Exception:
                pass
    # Last resort: walk QApplication top-level widgets
    try:
        app = QtWidgets.QApplication.instance()
        if app:
            for w in app.topLevelWidgets():
                if w.isVisible() and w.width() > 400:
                    return w
    except Exception:
        pass
    return None


def show_asset_browser():
    """Call this from MAXScript or the Python listener to open the panel."""
    global _dialog_instance

    # Keep only one instance
    if _dialog_instance is not None:
        try:
            _dialog_instance.close()
        except Exception:
            pass
        _dialog_instance = None

    parent = _get_max_main_window()

    _dialog_instance = AssetBrowserDialog(parent)
    _dialog_instance.show()
    _dialog_instance.raise_()
    _dialog_instance.activateWindow()
    return _dialog_instance


# Auto-open when executed directly by Python inside Max
if __name__ == "__main__":
    show_asset_browser()
