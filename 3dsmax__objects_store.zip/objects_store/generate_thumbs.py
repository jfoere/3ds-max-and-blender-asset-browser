"""
3ds Max Local Asset Browser - Thumbnail Generator
Run this script ONCE with regular Python (not inside Max) to generate PNG thumbnails.
Requires: Pillow  (pip install Pillow)

Usage: python generate_thumbs.py
"""

import json
import os
import math

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("ERROR: Pillow not installed. Run:  pip install Pillow")
    raise

# ─── Config ──────────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(SCRIPT_DIR, "catalog.json")
THUMBS_DIR   = os.path.join(SCRIPT_DIR, "thumbs")
THUMB_SIZE   = (256, 256)

CATEGORY_COLORS = {
    "Props":        ("#4CAF50", "#1B5E20"),   # green
    "Architecture": ("#2196F3", "#0D47A1"),   # blue
    "Nature":       ("#FFC107", "#E65100"),   # amber → orange gradient
    "Vehicles":     ("#F44336", "#B71C1C"),   # red
    "Furniture":    ("#9C27B0", "#4A148C"),   # purple
    "Other":        ("#607D8B", "#263238"),   # blue-grey
}

SHAPE_RENDERERS = {
    "box_wood":     "box",
    "barrel":       "cylinder",
    "stone_pillar": "pillar",
    "chair":        "chair",
    "low_wall":     "wall",
    "tree_pine":    "tree",
}

# ─── Drawing helpers ──────────────────────────────────────────────────────────

def lerp_color(c1, c2, t):
    """Interpolate between two hex colors."""
    r1, g1, b1 = int(c1[1:3],16), int(c1[3:5],16), int(c1[5:7],16)
    r2, g2, b2 = int(c2[1:3],16), int(c2[3:5],16), int(c2[5:7],16)
    r = int(r1 + (r2-r1)*t)
    g = int(g1 + (g2-g1)*t)
    b = int(b1 + (b2-b1)*t)
    return (r, g, b, 255)

def draw_gradient_bg(draw, w, h, c1, c2):
    for y in range(h):
        t = y / h
        color = lerp_color(c1, c2, t)
        draw.line([(0, y), (w, y)], fill=color)

def draw_box(draw, cx, cy, size, color):
    s = size * 0.38
    # Front face
    pts_front = [(cx-s, cy-s*0.6), (cx+s, cy-s*0.6), (cx+s, cy+s*0.6), (cx-s, cy+s*0.6)]
    draw.polygon(pts_front, fill=(*color, 220))
    # Top face (isometric top)
    pts_top = [(cx-s, cy-s*0.6), (cx+s, cy-s*0.6), (cx+s*1.35, cy-s), (cx-s*0.65, cy-s)]
    draw.polygon(pts_top, fill=(*tuple(min(255,c+60) for c in color), 220))
    # Right face
    pts_right = [(cx+s, cy-s*0.6), (cx+s*1.35, cy-s), (cx+s*1.35, cy+s*0.2), (cx+s, cy+s*0.6)]
    draw.polygon(pts_right, fill=(*tuple(max(0,c-40) for c in color), 220))

def draw_cylinder(draw, cx, cy, size, color):
    s = size * 0.32
    # Body
    draw.ellipse([cx-s, cy+s*0.7, cx+s, cy+s*1.1], fill=(*color, 200))
    draw.rectangle([cx-s, cy-s*0.8, cx+s, cy+s*0.9], fill=(*color, 220))
    # Top ellipse
    draw.ellipse([cx-s, cy-s*1.1, cx+s, cy-s*0.7], fill=(*tuple(min(255,c+70) for c in color), 230))

def draw_pillar(draw, cx, cy, size, color):
    s = size * 0.18
    # tall octagon approximation - just a tall rectangle with dark sides
    draw.rectangle([cx-s, cy-size*0.45, cx+s, cy+size*0.45], fill=(*color, 230))
    # top cap
    draw.ellipse([cx-s*1.3, cy-size*0.45-s*0.4, cx+s*1.3, cy-size*0.45+s*0.4],
                 fill=(*tuple(min(255,c+80) for c in color), 230))
    # side shading
    shade = tuple(max(0,c-60) for c in color)
    draw.rectangle([cx+s*0.3, cy-size*0.45, cx+s, cy+size*0.45], fill=(*shade, 180))

def draw_chair(draw, cx, cy, size, color):
    s = size * 0.3
    seat_y = cy + s * 0.1
    # Seat
    draw.rectangle([cx-s, seat_y, cx+s, seat_y+s*0.18], fill=(*color, 230))
    # Back
    draw.rectangle([cx-s, seat_y-s*0.9, cx-s*0.7, seat_y], fill=(*color, 210))
    # Legs
    leg_color = tuple(max(0,c-50) for c in color)
    for lx in [cx-s*0.8, cx+s*0.8]:
        draw.rectangle([lx-s*0.08, cy+s*0.28, lx+s*0.08, cy+s*0.85], fill=(*leg_color, 220))

def draw_wall(draw, cx, cy, size, color):
    s = size * 0.42
    h = size * 0.22
    # Main wall slab
    draw.rectangle([cx-s, cy-h, cx+s, cy+h], fill=(*color, 230))
    # Top highlight
    hi = tuple(min(255, c+70) for c in color)
    draw.rectangle([cx-s, cy-h, cx+s, cy-h+h*0.35], fill=(*hi, 200))
    # Brick pattern lines
    brick_color = tuple(max(0, c-60) for c in color)
    for row_y in [cy-h*0.3, cy+h*0.2]:
        draw.line([(cx-s, row_y), (cx+s, row_y)], fill=(*brick_color, 180), width=2)
    for col_x in [cx-s*0.5, cx, cx+s*0.5]:
        draw.line([(col_x, cy-h), (col_x, cy+h)], fill=(*brick_color, 100), width=2)

def draw_tree(draw, cx, cy, size, color):
    # Trunk
    trunk = (101, 67, 33)
    tw = size * 0.07
    draw.rectangle([cx-tw, cy+size*0.05, cx+tw, cy+size*0.45], fill=(*trunk, 240))
    # Three cone tiers
    tiers = [
        (size*0.42, cy+size*0.08, 0),
        (size*0.32, cy-size*0.12, 1),
        (size*0.20, cy-size*0.30, 2),
    ]
    for radius, apex_y, i in tiers:
        shade = tuple(max(0, c - i*25) for c in color)
        pts = [(cx-radius, apex_y+size*0.2), (cx+radius, apex_y+size*0.2), (cx, apex_y)]
        draw.polygon(pts, fill=(*shade, 235))

SHAPE_FNS = {
    "box":      draw_box,
    "cylinder": draw_cylinder,
    "pillar":   draw_pillar,
    "chair":    draw_chair,
    "wall":     draw_wall,
    "tree":     draw_tree,
}

# ─── Main generation ──────────────────────────────────────────────────────────

def make_thumbnail(asset, out_path):
    w, h = THUMB_SIZE
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    cat = asset.get("category", "Other")
    c1, c2 = CATEGORY_COLORS.get(cat, CATEGORY_COLORS["Other"])
    draw_gradient_bg(draw, w, h, c1, c2)

    # Decode main color for shapes
    r, g, b = int(c1[1:3],16), int(c1[3:5],16), int(c1[5:7],16)
    main_color = (r, g, b)

    shape_key = SHAPE_RENDERERS.get(asset["id"], "box")
    draw_fn = SHAPE_FNS.get(shape_key, draw_box)
    draw_fn(draw, w//2, int(h*0.48), min(w,h)//2, main_color)

    # Category badge top-left
    badge_c = tuple(max(0, c - 40) for c in main_color) + (200,)
    draw.rounded_rectangle([8, 8, 90, 28], radius=6, fill=badge_c)
    try:
        font_sm = ImageFont.truetype("arial.ttf", 11)
        font_lg = ImageFont.truetype("arial.ttf", 15)
    except Exception:
        font_sm = ImageFont.load_default()
        font_lg = font_sm
    draw.text((12, 11), cat, font=font_sm, fill=(255,255,255,230))

    # Asset name at bottom
    name_bg = (0, 0, 0, 150)
    draw.rectangle([0, h-46, w, h], fill=name_bg)
    name = asset["name"]
    bbox = draw.textbbox((0,0), name, font=font_lg)
    tw_text = bbox[2] - bbox[0]
    draw.text(((w - tw_text)//2, h-36), name, font=font_lg, fill=(255,255,255,255))

    # Subtle border
    border_c = tuple(min(255, c+50) for c in main_color) + (120,)
    draw.rounded_rectangle([2, 2, w-3, h-3], radius=10, outline=border_c, width=2)

    img.save(out_path, "PNG")
    print(f"  Generated: {os.path.basename(out_path)}")


def main():
    os.makedirs(THUMBS_DIR, exist_ok=True)

    with open(CATALOG_PATH, "r") as f:
        catalog = json.load(f)

    print(f"Generating {len(catalog)} thumbnails into: {THUMBS_DIR}")
    for asset in catalog:
        thumb_rel = asset.get("thumbnail", f"thumbs/{asset['id']}.png")
        out_path = os.path.join(SCRIPT_DIR, thumb_rel.replace("/", os.sep))
        make_thumbnail(asset, out_path)

    print("Done!")


if __name__ == "__main__":
    main()
