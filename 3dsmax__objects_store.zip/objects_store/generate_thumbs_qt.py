"""
3ds Max Asset Browser - Qt-based Thumbnail Generator
=====================================================
Uses PySide2 (already available in 3ds Max) instead of Pillow.
Run from INSIDE 3ds Max via:
    python.ExecuteFile @"H:\3D\...\objects_store\generate_thumbs_qt.py"

OR click "Generate Previews" inside the Asset Browser panel.
"""

from __future__ import annotations
import json
import os
import math

from PySide2 import QtGui, QtCore
from PySide2.QtCore import Qt
from PySide2.QtGui import (
    QImage, QPainter, QColor, QLinearGradient, QBrush,
    QPen, QFont, QFontMetrics, QPainterPath
)

SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(SCRIPT_DIR, "catalog.json")
THUMBS_DIR   = os.path.join(SCRIPT_DIR, "thumbs")
W, H         = 256, 256

CATEGORY_PALETTE = {
    "Props":        ("#4CAF50", "#1B5E20"),
    "Architecture": ("#2196F3", "#0D47A1"),
    "Nature":       ("#FFC107", "#E65100"),
    "Vehicles":     ("#F44336", "#B71C1C"),
    "Furniture":    ("#9C27B0", "#4A148C"),
    "Other":        ("#607D8B", "#263238"),
}

SHAPE_FOR_ID = {
    "box_wood":     "box",
    "barrel":       "cylinder",
    "stone_pillar": "pillar",
    "chair":        "chair",
    "low_wall":     "wall",
    "tree_pine":    "tree",
}


# ─── Helpers ──────────────────────────────────────────────────────────────────

def qc(hex_str: str, alpha: int = 255) -> QColor:
    c = QColor(hex_str)
    c.setAlpha(alpha)
    return c

def darker(hex_str: str, factor: int = 60) -> QColor:
    c = QColor(hex_str)
    return c.darker(100 + factor)

def lighter(hex_str: str, factor: int = 60) -> QColor:
    c = QColor(hex_str)
    return c.lighter(100 + factor)


# ─── Shape renderers ──────────────────────────────────────────────────────────

def draw_box(p: QPainter, cx: float, cy: float, size: float, col: str):
    s = size * 0.36
    # Front face
    front = QtCore.QRectF(cx - s, cy - s * 0.6, s * 2, s * 1.4)
    grad = QLinearGradient(cx - s, cy - s * 0.6, cx - s, cy + s * 0.8)
    grad.setColorAt(0, lighter(col, 30))
    grad.setColorAt(1, qc(col))
    p.setBrush(QBrush(grad))
    p.setPen(Qt.NoPen)
    p.drawRect(front)

    # Top face (parallelogram)
    top = QtGui.QPolygonF([
        QtCore.QPointF(cx - s,       cy - s * 0.6),
        QtCore.QPointF(cx + s,       cy - s * 0.6),
        QtCore.QPointF(cx + s * 1.4, cy - s * 1.1),
        QtCore.QPointF(cx - s * 0.6, cy - s * 1.1),
    ])
    grad2 = QLinearGradient(cx, cy - s * 0.6, cx, cy - s * 1.1)
    grad2.setColorAt(0, lighter(col, 70))
    grad2.setColorAt(1, lighter(col, 40))
    p.setBrush(QBrush(grad2))
    p.drawPolygon(top)

    # Right face (parallelogram)
    right = QtGui.QPolygonF([
        QtCore.QPointF(cx + s,       cy - s * 0.6),
        QtCore.QPointF(cx + s * 1.4, cy - s * 1.1),
        QtCore.QPointF(cx + s * 1.4, cy + s * 0.3),
        QtCore.QPointF(cx + s,       cy + s * 0.8),
    ])
    p.setBrush(QBrush(darker(col, 50)))
    p.drawPolygon(right)

    # Wood grain lines on front
    p.setPen(QPen(QColor(0, 0, 0, 30), 1.5))
    for i in range(1, 3):
        y_line = cy - s * 0.6 + (s * 1.4) * i / 3
        p.drawLine(QtCore.QLineF(cx - s, y_line, cx + s, y_line))


def draw_cylinder(p: QPainter, cx: float, cy: float, size: float, col: str):
    rx = size * 0.32
    ry_cap = rx * 0.35
    body_top = cy - size * 0.42
    body_bot = cy + size * 0.42

    # Body
    grad = QLinearGradient(cx - rx, 0, cx + rx, 0)
    grad.setColorAt(0,   darker(col, 60))
    grad.setColorAt(0.3, lighter(col, 10))
    grad.setColorAt(0.7, qc(col))
    grad.setColorAt(1,   darker(col, 40))
    p.setBrush(QBrush(grad))
    p.setPen(Qt.NoPen)
    p.drawRect(QtCore.QRectF(cx - rx, body_top, rx * 2, body_bot - body_top))

    # Bottom ellipse
    p.setBrush(QBrush(darker(col, 70)))
    p.drawEllipse(QtCore.QRectF(cx - rx, body_bot - ry_cap, rx * 2, ry_cap * 2))

    # Top ellipse highlight
    grad_top = QLinearGradient(cx - rx, body_top - ry_cap, cx + rx, body_top + ry_cap)
    grad_top.setColorAt(0, lighter(col, 90))
    grad_top.setColorAt(1, lighter(col, 40))
    p.setBrush(QBrush(grad_top))
    p.drawEllipse(QtCore.QRectF(cx - rx, body_top - ry_cap, rx * 2, ry_cap * 2))

    # Barrel hoop rings
    p.setPen(QPen(darker(col, 80), 3))
    p.setBrush(Qt.NoBrush)
    for frac in [0.2, 0.5, 0.8]:
        ring_y = body_top + (body_bot - body_top) * frac
        p.drawEllipse(QtCore.QRectF(cx - rx, ring_y - ry_cap * 0.5, rx * 2, ry_cap))


def draw_pillar(p: QPainter, cx: float, cy: float, size: float, col: str):
    pw = size * 0.22
    ph = size * 0.85

    # Shaft gradient
    grad = QLinearGradient(cx - pw, 0, cx + pw, 0)
    grad.setColorAt(0,   darker(col, 70))
    grad.setColorAt(0.4, lighter(col, 20))
    grad.setColorAt(1,   darker(col, 40))
    p.setBrush(QBrush(grad))
    p.setPen(Qt.NoPen)
    p.drawRect(QtCore.QRectF(cx - pw, cy - ph / 2, pw * 2, ph))

    cap_h = size * 0.1
    # Capital (top cap)
    cap_grad = QLinearGradient(cx, cy - ph / 2 - cap_h, cx, cy - ph / 2)
    cap_grad.setColorAt(0, lighter(col, 80))
    cap_grad.setColorAt(1, lighter(col, 20))
    p.setBrush(QBrush(cap_grad))
    p.drawRect(QtCore.QRectF(cx - pw * 1.4, cy - ph / 2 - cap_h, pw * 2.8, cap_h))

    # Base
    p.setBrush(QBrush(darker(col, 30)))
    p.drawRect(QtCore.QRectF(cx - pw * 1.4, cy + ph / 2, pw * 2.8, cap_h))

    # Flute lines
    p.setPen(QPen(darker(col, 80), 1, Qt.DotLine))
    for i in range(1, 4):
        x_line = cx - pw + pw * 2 * i / 4
        p.drawLine(QtCore.QLineF(x_line, cy - ph / 2, x_line, cy + ph / 2))


def draw_chair(p: QPainter, cx: float, cy: float, size: float, col: str):
    s = size * 0.36
    seat_y = cy + size * 0.05

    # Seat
    seat_grad = QLinearGradient(cx - s, seat_y, cx - s, seat_y + s * 0.2)
    seat_grad.setColorAt(0, lighter(col, 40))
    seat_grad.setColorAt(1, qc(col))
    p.setBrush(QBrush(seat_grad))
    p.setPen(Qt.NoPen)
    p.drawRect(QtCore.QRectF(cx - s, seat_y, s * 2, s * 0.22))

    # Backrest
    back_grad = QLinearGradient(cx - s, seat_y - s * 0.9, cx - s + s * 0.35, seat_y - s * 0.9)
    back_grad.setColorAt(0, lighter(col, 20))
    back_grad.setColorAt(1, qc(col))
    p.setBrush(QBrush(back_grad))
    p.drawRect(QtCore.QRectF(cx - s, seat_y - s * 0.9, s * 0.35, s * 0.9))

    # Legs
    p.setBrush(QBrush(darker(col, 40)))
    leg_w = s * 0.1
    for lx in [cx - s * 0.8, cx + s * 0.7]:
        p.drawRect(QtCore.QRectF(lx, seat_y + s * 0.22, leg_w, s * 0.68))


def draw_wall(p: QPainter, cx: float, cy: float, size: float, col: str):
    w2 = size * 0.48
    h2 = size * 0.24

    # Wall body
    grad = QLinearGradient(cx - w2, cy - h2, cx - w2, cy + h2)
    grad.setColorAt(0, lighter(col, 40))
    grad.setColorAt(1, qc(col))
    p.setBrush(QBrush(grad))
    p.setPen(Qt.NoPen)
    p.drawRect(QtCore.QRectF(cx - w2, cy - h2, w2 * 2, h2 * 2))

    # Brick mortar grid
    p.setPen(QPen(darker(col, 80), 1.5))
    # horizontal rows
    for row in range(1, 4):
        y = cy - h2 + (h2 * 2) * row / 4
        p.drawLine(QtCore.QLineF(cx - w2, y, cx + w2, y))
    # vertical joints (offset per row)
    row_h = (h2 * 2) / 4
    for row in range(4):
        y_top = cy - h2 + row * row_h
        offset = w2 * 0.5 if row % 2 == 0 else 0
        x = cx - w2 + offset
        while x < cx + w2:
            p.drawLine(QtCore.QLineF(x, y_top, x, y_top + row_h))
            x += w2 * 0.5

    # Top highlight
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(QColor(255, 255, 255, 35)))
    p.drawRect(QtCore.QRectF(cx - w2, cy - h2, w2 * 2, h2 * 0.4))


def draw_tree(p: QPainter, cx: float, cy: float, size: float, col: str):
    # Trunk
    tw = size * 0.08
    trunk_top = cy + size * 0.08
    p.setPen(Qt.NoPen)
    trunk_grad = QLinearGradient(cx - tw, 0, cx + tw, 0)
    trunk_grad.setColorAt(0, QColor("#5D4037"))
    trunk_grad.setColorAt(1, QColor("#8D6E63"))
    p.setBrush(QBrush(trunk_grad))
    p.drawRect(QtCore.QRectF(cx - tw, trunk_top, tw * 2, size * 0.42))

    # Three cone tiers (bottom → top)
    tiers = [
        (size * 0.44, cy + size * 0.12,  0),
        (size * 0.34, cy - size * 0.10,  1),
        (size * 0.22, cy - size * 0.30,  2),
    ]
    for radius, apex_y, i in tiers:
        base_y = apex_y + size * 0.24
        shade_factor = i * 25
        top_c = QColor(col)
        bot_c = darker(col, shade_factor + 20)
        cone_grad = QLinearGradient(cx, apex_y, cx, base_y)
        cone_grad.setColorAt(0, top_c)
        cone_grad.setColorAt(1, bot_c)
        p.setBrush(QBrush(cone_grad))

        triangle = QtGui.QPolygonF([
            QtCore.QPointF(cx - radius, base_y),
            QtCore.QPointF(cx + radius, base_y),
            QtCore.QPointF(cx,          apex_y),
        ])
        p.drawPolygon(triangle)

        # Shadow edge
        p.setPen(QPen(darker(col, 80), 1))
        p.setBrush(Qt.NoBrush)
        p.drawPolygon(triangle)
        p.setPen(Qt.NoPen)


SHAPE_FNS = {
    "box":      draw_box,
    "cylinder": draw_cylinder,
    "pillar":   draw_pillar,
    "chair":    draw_chair,
    "wall":     draw_wall,
    "tree":     draw_tree,
}


# ─── Main thumbnail renderer ──────────────────────────────────────────────────

def make_thumbnail(asset: dict, out_path: str) -> bool:
    cat = asset.get("category", "Other")
    c1, c2 = CATEGORY_PALETTE.get(cat, CATEGORY_PALETTE["Other"])

    img = QImage(W, H, QImage.Format_ARGB32)
    img.fill(Qt.transparent)

    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)

    # ── Background gradient ───────────────────────────────────────────
    bg_grad = QLinearGradient(0, 0, 0, H)
    bg_grad.setColorAt(0, QColor(c2).darker(110))
    bg_grad.setColorAt(1, QColor(c2).darker(160))
    path = QPainterPath()
    path.addRoundedRect(QtCore.QRectF(0, 0, W, H), 14, 14)
    p.fillPath(path, QBrush(bg_grad))

    # ── Shape ─────────────────────────────────────────────────────────
    shape_key = SHAPE_FOR_ID.get(asset["id"], "box")
    draw_fn = SHAPE_FNS.get(shape_key, draw_box)
    draw_fn(p, W / 2, H * 0.48, min(W, H) / 2.1, c1)

    # ── Category badge ────────────────────────────────────────────────
    badge_bg = QColor(c2)
    badge_bg.setAlpha(200)
    p.setBrush(QBrush(badge_bg))
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(QtCore.QRectF(8, 8, 88, 22), 5, 5)
    font_badge = QFont("Segoe UI", 9, QFont.Bold)
    p.setFont(font_badge)
    p.setPen(QColor(255, 255, 255, 220))
    p.drawText(QtCore.QRectF(8, 8, 88, 22), Qt.AlignCenter, cat)

    # ── Name label at bottom ─────────────────────────────────────────
    name_bg = QColor(0, 0, 0, 160)
    p.setBrush(QBrush(name_bg))
    p.setPen(Qt.NoPen)
    p.drawRect(QtCore.QRectF(0, H - 44, W, 44))

    font_name = QFont("Segoe UI", 12, QFont.Bold)
    p.setFont(font_name)
    p.setPen(QColor(255, 255, 255, 255))
    p.drawText(QtCore.QRectF(8, H - 40, W - 16, 36), Qt.AlignCenter | Qt.AlignVCenter,
               asset["name"])

    # ── Border ────────────────────────────────────────────────────────
    border_c = QColor(c1)
    border_c.setAlpha(120)
    p.setBrush(Qt.NoBrush)
    p.setPen(QPen(border_c, 2))
    path2 = QPainterPath()
    path2.addRoundedRect(QtCore.QRectF(1, 1, W - 2, H - 2), 13, 13)
    p.drawPath(path2)

    p.end()

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    ok = img.save(out_path, "PNG")
    status = "OK" if ok else "FAILED"
    print(f"  [{status}] {os.path.basename(out_path)}")
    return ok


def generate_all_thumbnails() -> int:
    """Generate thumbnails for all assets in catalog. Returns count generated."""
    if not os.path.isfile(CATALOG_PATH):
        print(f"ERROR: catalog.json not found at {CATALOG_PATH}")
        return 0

    with open(CATALOG_PATH, "r", encoding="utf-8") as f:
        catalog = json.load(f)

    os.makedirs(THUMBS_DIR, exist_ok=True)
    print(f"Generating {len(catalog)} thumbnails...")
    count = 0
    for asset in catalog:
        thumb_rel = asset.get("thumbnail", f"thumbs/{asset['id']}.png")
        out_path  = os.path.join(SCRIPT_DIR, thumb_rel.replace("/", os.sep))
        if make_thumbnail(asset, out_path):
            count += 1

    print(f"Done! {count}/{len(catalog)} thumbnails generated.")
    return count


if __name__ == "__main__":
    # Works when run via python.ExecuteFile inside 3ds Max
    # OR from any Python that has PySide2 installed
    import sys
    app = None
    if not __import__("PySide2").QtWidgets.QApplication.instance():
        app = __import__("PySide2").QtWidgets.QApplication(sys.argv)
    generate_all_thumbnails()
